package shared;

public class ExitProgram extends Exception {
    public ExitProgram(String msg) {
        super(msg);
    }
}
