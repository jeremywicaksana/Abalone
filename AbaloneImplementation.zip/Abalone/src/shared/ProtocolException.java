package shared;

public class ProtocolException extends Exception {
    public ProtocolException(String msg) {
        super(msg);
    }
}
