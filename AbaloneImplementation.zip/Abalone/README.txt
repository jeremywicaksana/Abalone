This is a procedure to run abalone game this game can be played by 2/3/4 players
How to run the abalone game:
1.open command prompt in this folder to run the server
2.type "javac server/AbaloneServer.java" if it has not been compiled, if it is already then go to step 3
3.type "java server/AbaloneServer" to run the server of the game
4.open another command prompt to run the client.
5.type "javac client/AbaloneClient.java" if it has not been compiled, if it is already then go to step 6.
6.type "java client/AbaloneClient" to run the client to play game.
7.if wants to play x player locally then do step 4-6 with x many times.
8.you now can play the game.